package csci391.microservices.lab3.order_processor_api.services;

import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
import csci391.microservices.lab3.order_processor_api.configs.MessageSenderConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MessageSenderService {

    private final ServiceBusSenderClient serviceBusSenderClient;

    public MessageSenderService(@Autowired MessageSenderConfig messageSenderConfig){
        DefaultAzureCredential credential = new DefaultAzureCredentialBuilder()
                .build();

        this.serviceBusSenderClient = new ServiceBusClientBuilder()
                .connectionString(messageSenderConfig.getConnectionString())
                .sender()
                .queueName(messageSenderConfig.getQueueName())
                .buildClient();
    }

    public void sendMessage(ServiceBusMessage message)
    {
        // send one message to the queue
        this.serviceBusSenderClient.sendMessage(message);
        System.out.println("Sent a single message to the queue: " + this.serviceBusSenderClient.getEntityPath());
    }
}
