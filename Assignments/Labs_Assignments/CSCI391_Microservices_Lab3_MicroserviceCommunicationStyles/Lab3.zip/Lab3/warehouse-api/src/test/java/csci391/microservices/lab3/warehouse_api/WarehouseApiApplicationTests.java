package csci391.microservices.lab3.warehouse_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WarehouseApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
