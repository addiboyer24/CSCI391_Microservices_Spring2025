package csci391.microservices.lab3.order_processor_api.controllers;

import com.azure.json.models.JsonObject;
import com.azure.messaging.servicebus.*;
import com.sun.jna.platform.win32.Guid;
import csci391.microservices.lab3.order_processor_api.clients.WarehouseClient;
import csci391.microservices.lab3.order_processor_api.services.MessageSenderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {

    private final WarehouseClient warehouseClient;

    private final MessageSenderService messageSenderService;

    public OrderController(@Autowired WarehouseClient warehouseClient,
                           @Autowired MessageSenderService messageSenderService){
        this.warehouseClient = warehouseClient;
        this.messageSenderService = messageSenderService;
    }

    @PostMapping("/place")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<String> placeOrder(@RequestBody String request){
        JsonObject reserveStockRequest = new JsonObject();
        ResponseEntity<String> warehouseResponse = this.warehouseClient.reserveStock(reserveStockRequest.toString());
        return new ResponseEntity<String>(Guid.GUID.newGuid().toGuidString(), HttpStatus.CREATED);
    }

    @PostMapping("/placeasync")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<String> placeOrderAsync(@RequestBody String request){
        this.messageSenderService.sendMessage(new ServiceBusMessage(""));
        return new ResponseEntity<String>("Your request to place order has been initiated.", HttpStatus.OK);
    }
}
