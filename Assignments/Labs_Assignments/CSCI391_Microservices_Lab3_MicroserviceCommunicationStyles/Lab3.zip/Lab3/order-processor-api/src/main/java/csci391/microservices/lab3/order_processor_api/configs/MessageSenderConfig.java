package csci391.microservices.lab3.order_processor_api.configs;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "message.sender")
@Getter
@Setter
public class MessageSenderConfig {

    private String connectionString;
    private String queueName;
}


