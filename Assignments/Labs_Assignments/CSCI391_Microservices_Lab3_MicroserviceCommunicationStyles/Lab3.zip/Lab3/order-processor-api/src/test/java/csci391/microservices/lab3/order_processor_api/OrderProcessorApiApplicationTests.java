package csci391.microservices.lab3.order_processor_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.util.Assert;

@SpringBootTest(classes = OrderProcessorApiApplicationTests.class)
class OrderProcessorApiApplicationTests {

	@Test
	void contextLoads() {
		Assert.isTrue(true, "");
	}

}
