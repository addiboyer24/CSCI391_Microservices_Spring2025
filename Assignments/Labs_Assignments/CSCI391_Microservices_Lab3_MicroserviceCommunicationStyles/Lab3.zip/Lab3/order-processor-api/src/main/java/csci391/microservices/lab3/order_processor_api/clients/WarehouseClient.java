package csci391.microservices.lab3.order_processor_api.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "${feign.name}", url = "${feign.url}")
public interface WarehouseClient {
    @PostMapping("/stock/reserve")
    public ResponseEntity<String> reserveStock(@RequestBody() String stockRequest);
}
