package csci391.microservices.lab3.warehouse_api.controllers;

import csci391.microservices.lab3.warehouse_api.services.MessageReceiverService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stock")
public class StockController {

    private final MessageReceiverService messageReceiverService;

    public StockController(@Autowired MessageReceiverService messageReceiverService){
        this.messageReceiverService = messageReceiverService;
    }

    @PostMapping("/reserve")
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<String> reserveStock(@RequestBody() String stockRequest){
        return new ResponseEntity<String>("", HttpStatus.OK);
    }

    @Scheduled(fixedDelay = 10000)
    public void reserveStockAsync() throws InterruptedException {
        System.out.println("Reading Service Bus Message");
        this.messageReceiverService.receiveMessages();
    }
}
