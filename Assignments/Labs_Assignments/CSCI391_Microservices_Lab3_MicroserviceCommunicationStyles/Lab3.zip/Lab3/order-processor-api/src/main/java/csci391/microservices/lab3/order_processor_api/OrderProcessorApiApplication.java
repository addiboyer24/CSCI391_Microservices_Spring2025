package csci391.microservices.lab3.order_processor_api;

import csci391.microservices.lab3.order_processor_api.configs.MessageSenderConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableFeignClients
@EnableScheduling
@EnableConfigurationProperties(MessageSenderConfig.class)
public class OrderProcessorApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderProcessorApiApplication.class, args);
	}

}
