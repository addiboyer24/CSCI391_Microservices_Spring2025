package csci391.microservices.lab3.warehouse_api.configs;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "message.receiver")
@Getter
@Setter
public class MessageReceiverConfig {

    private String connectionString;
    private String queueName;
}

