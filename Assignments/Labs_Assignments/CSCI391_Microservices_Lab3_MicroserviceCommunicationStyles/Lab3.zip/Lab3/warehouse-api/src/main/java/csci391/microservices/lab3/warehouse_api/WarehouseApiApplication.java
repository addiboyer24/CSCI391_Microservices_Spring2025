package csci391.microservices.lab3.warehouse_api;

import csci391.microservices.lab3.warehouse_api.configs.MessageReceiverConfig;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(MessageReceiverConfig.class)
public class WarehouseApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(WarehouseApiApplication.class, args);
	}
}
